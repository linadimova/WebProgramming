package mk.finki.ukim.mk.lab.bootsrap;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.*;
import mk.finki.ukim.mk.lab.repository.jpa.CategoryRepository;
import mk.finki.ukim.mk.lab.repository.jpa.EventRepository;
import mk.finki.ukim.mk.lab.repository.jpa.LocationRepository;
import mk.finki.ukim.mk.lab.repository.jpa.UserRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> events = null;
    public static List<EventBooking> MyBookings = null;
    public static List<Category> categories = null;
    public static List<Location> locations = null;
    public static List<User> users = null;

    private final CategoryRepository categoryRepository;
    private final UserRepository userRepository;
    private final LocationRepository locationRepository;
    private final EventRepository eventRepository;

    public DataHolder(CategoryRepository categoryRepository, UserRepository userRepository,
                      LocationRepository locationRepository, EventRepository eventRepository) {
        this.categoryRepository = categoryRepository;
        this.userRepository = userRepository;
        this.locationRepository = locationRepository;
        this.eventRepository = eventRepository;
    }

    @PostConstruct
    public void init() {
        //Categories
        categories = new ArrayList<>();
        if (this.categoryRepository.count() == 0) {
            categories.add(new Category("Innovation"));
            categories.add(new Category("Culinary"));
            categories.add(new Category("Fitness"));
            categories.add(new Category("Education"));
            categories.add(new Category("Adventure"));
            categories.add(new Category("Science"));
            this.categoryRepository.saveAll(categories);
        }

        //Locations
        locations = new ArrayList<>();
        if (this.locationRepository.count() == 0) {
            locations.add(new Location("Sunset Plaza", "Beverly Hills, USA", "20,000", "Famous sunset-view venue known for VIP events."));
            locations.add(new Location("Crystal Beach", "Florida, USA", "30,000", "Known for beach parties and live concerts."));
            locations.add(new Location("Downtown Expo", "San Francisco, USA", "15,000", "A modern space for expos and technology events."));
            locations.add(new Location("Mountain Peak Arena", "Rocky Mountains, USA", "50,000", "Outdoor arena perfect for large festivals."));
            locations.add(new Location("Sky Tower", "Dubai, UAE", "70,000", "A luxury venue for business and high-profile events."));
            locations.add(new Location("The Hive", "Berlin, Germany", "25,000", "Underground venue for techno and electronic music events."));
            locations.add(new Location("Oceanic Pavilion", "Sydney, Australia", "10,000", "A unique venue with a view of the Pacific Ocean."));
            locations.add(new Location("Palace Hall", "Paris, France", "12,000", "Historic venue for cultural and art exhibitions."));
            locations.add(new Location("Galaxy Dome", "Tokyo, Japan", "60,000", "A futuristic venue for tech conferences and space events."));
            locations.add(new Location("The Coliseum", "Rome, Italy", "80,000", "A grand ancient structure used for modern events."));
            this.locationRepository.saveAll(locations);
        }

        //Events
        events = new ArrayList<>();
        if (this.eventRepository.count() == 0) {
            events.add(new Event("Sundance Film Festival", "Independent film showcase", 9, categories.get(3), locations.get(0), 100));
            events.add(new Event("Culinary Mastery", "Cooking workshop and competition", 8, categories.get(1), locations.get(1), 200));
            events.add(new Event("Fitness Bootcamp", "Outdoor fitness and wellness", 7, categories.get(2), locations.get(2), 150));
            events.add(new Event("Future of Learning", "Interactive educational summit", 10, categories.get(3), locations.get(3), 250));
            events.add(new Event("Galactic Expo", "Technology showcase", 9, categories.get(5), locations.get(4), 500));
            events.add(new Event("Adventure Seekers", "Extreme sports convention", 8, categories.get(4), locations.get(5), 80));
            events.add(new Event("Tech Innovators Summit", "Innovation in tech and AI", 10, categories.get(0), locations.get(6), 300));
            events.add(new Event("Jazz Nights", "Live jazz music festival", 7, categories.get(1), locations.get(7), 50));
            events.add(new Event("Space Odyssey", "Astronomy and space exploration event", 9, categories.get(5), locations.get(8), 150));
            events.add(new Event("Artistic Visions", "Artistic photography and paintings exhibition", 6, categories.get(4), locations.get(9), 120));
            this.eventRepository.saveAll(events);
        }

        //Users
        users = new ArrayList<>();
        if (this.userRepository.count() == 0) {
            users.add(new User("alex.johnson", "pass123", "Alex", "Johnson"));
            users.add(new User("sara.kovacs", "cookie", "Sara", "Kovacs"));
            users.add(new User("lucas.bright", "star56", "Lucas", "Bright"));
            this.userRepository.saveAll(users);
        }
    }
}
